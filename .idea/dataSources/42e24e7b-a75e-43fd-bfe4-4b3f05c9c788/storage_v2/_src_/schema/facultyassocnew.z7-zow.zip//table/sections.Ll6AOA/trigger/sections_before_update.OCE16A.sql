create definer = root@localhost trigger sections_BEFORE_UPDATE
    before UPDATE
    on sections
    for each row
BEGIN
	
	IF(old.title != new.title OR old.content != new.content OR old.sectionNo != new.sectionNo OR old.versionNo != new.versionNo)THEN
		SET new.audit_action_type = 'UPDATED';
		SET new.audit_user_id = new.authorId;
		SET new.lastUpdated = new.audit_timestamp;
        SET new.old_title = old.title;
        SET new.old_content = old.content;
        SET new.old_sectionNo = old.sectionNo;
        SET new.old_versionNo = old.versionNo;
	ELSEIF(old.statusId != new.statusId) THEN
		SET new.audit_action_type = 'STATUSED';
		SET new.audit_user_id = new.statusedById;
		SET new.statusedOn = new.audit_timestamp;
        SET new.availabilityOn = new.audit_timestamp;
        SET new.availabilityById = new.audit_user_id;
        SET new.availabilityId = '1';
		IF(old.stepId != new.stepId) THEN
			SET new.audit_action_type = 'STATUSED/MOVED';
			SET new.steppedOn = new.audit_timestamp;
		END IF;
	ELSEIF(old.stepId != new.stepId) THEN
		SET new.audit_action_type = 'MOVED';
		SET new.audit_user_id = new.steppedById;
		SET new.steppedOn = new.audit_timestamp;
        SET new.availabilityOn = new.audit_timestamp;
        SET new.availabilityById = new.audit_user_id;
        SET new.availabilityId = '1';
	ELSEIF(old.lifecycleId != new.lifecycleId) THEN
		SET new.audit_action_type = 'CYCLED';
		SET new.audit_user_id = new.lifecycledById;
		SET new.lifecycledOn = new.audit_timestamp;
	ELSEIF(old.availabilityId != new.availabilityId) THEN
		SET new.audit_action_type = 'LOCKED';
		SET new.audit_user_id = new.availabilityById;
		SET new.availabilityOn = new.audit_timestamp;
	END IF;
	
	IF (new.audit_action_type != 'LOCKED') THEN
		SET new.remark_action_type = new.audit_action_type;
		SET new.remark_user_id = new.audit_user_id;
		SET new.remark_timestamp = new.audit_timestamp;
	END IF;
	
	INSERT INTO section_versions
		(sectionId, 
        firstAuthorId, 
        authorId, 
        timeCreated, 
        lastUpdated,
				availabilityId,
				availabilityOn,
				availabilityById,
				steppedById,
				steppedOn,
				stepId,
        statusedById,
				statusedOn,
        statusId,
				lifecycleId,
				lifecycledById,
				lifecycledOn,
        versionNo, 
        title, 
        content,
        sectionNo,
        old_title,
        old_content,
        old_sectionNo,
        old_versionNo,
        remarks,
				audit_action_type,
				audit_user_id,
				audit_timestamp,
				remark_action_type,
				remark_user_id,
				remark_timestamp)
        VALUES 
        (new.id, 
        new.firstAuthorId, 
        new.authorId, 
        new.timeCreated, 
        new.lastUpdated,
				new.availabilityId,
				new.availabilityOn,
				new.availabilityById,
				new.steppedById,
				new.steppedOn,
				new.stepId,
        new.statusedById,
				new.statusedOn,
        new.statusId,
				new.lifecycleId,
				new.lifecycledById,
				new.lifecycledOn,
        new.versionNo, 
        new.title, 
        new.content,
        new.sectionNo,
        new.old_title,
        new.old_content,
        new.old_sectionNo,
        new.old_versionNo,
        new.remarks,
				new.audit_action_type,
				new.audit_user_id,
				new.audit_timestamp,
				new.remark_action_type,
				new.remark_user_id,
				new.remark_timestamp);
END;

