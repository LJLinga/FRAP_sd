CREATE TRIGGER before_publish_post
BEFORE UPDATE ON posts
FOR EACH ROW
  IF (new.statusId = 4 AND old.timePublished IS NULL) THEN
	SET new.timePublished = new.lastUpdated;
END IF;
