CREATE TRIGGER before_trash_post
BEFORE UPDATE ON posts
FOR EACH ROW
  BEGIN
    IF (new.statusId = 5 AND old.statusId!=new.statusId) THEN
	SET new.previousStatusId = old.statusId ;
END IF;
END;
