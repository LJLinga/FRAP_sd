CREATE TRIGGER documents_AFTER_INSERT
AFTER INSERT ON documents
FOR EACH ROW
  BEGIN
	INSERT INTO doc_versions
		(documentId, authorId, versionNo, title, filePath, timeCreated)
        VALUES (new.documentId, new.authorId, new.versionNo, new.title, new.filePath, new.timeCreated);
END;
