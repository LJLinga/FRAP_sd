CREATE TRIGGER documents_AFTER_UPDATE
AFTER UPDATE ON documents
FOR EACH ROW
  BEGIN
	IF(old.statusId != new.statusId OR old.title != new.title OR old.filePath!=new.filePath OR old.versionNo != new.versionNo) THEN
		INSERT INTO doc_versions
		(documentId, authorId, statusId, approvedById, versionNo, title, filePath, timeCreated)
        VALUES (new.documentId, new.authorId, new.statusId, new.statusedById, new.versionNo, new.title,new.filePath,new.lastUpdated);
	END IF;
END;
