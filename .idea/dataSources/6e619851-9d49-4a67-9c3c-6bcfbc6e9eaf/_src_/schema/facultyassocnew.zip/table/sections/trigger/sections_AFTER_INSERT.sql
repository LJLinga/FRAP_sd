CREATE TRIGGER sections_AFTER_INSERT
AFTER INSERT ON sections
FOR EACH ROW
  BEGIN
	INSERT INTO section_versions
		(sectionId, statusId, authorId, approvedById, sectionNo, title, content)
        VALUES (new.id, new.statusId, new.authorId, new.approvedById, new.sectionNo, new.title, new.content);
END;
