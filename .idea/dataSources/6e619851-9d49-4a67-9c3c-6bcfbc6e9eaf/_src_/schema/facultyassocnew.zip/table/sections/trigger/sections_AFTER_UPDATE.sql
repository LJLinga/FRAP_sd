CREATE TRIGGER sections_AFTER_UPDATE
AFTER UPDATE ON sections
FOR EACH ROW
  BEGIN
	IF(old.statusId != new.statusId OR old.title != new.title OR old.content!=new.content OR old.sectionNo != new.sectionNo) THEN
		INSERT INTO section_versions
		(sectionId, authorId, statusId, approvedById, sectionNo, title, content)
        VALUES (new.id, new.authorId, new.statusId, new.approvedById, new.sectionNo, new.title, new.content);
	END IF;
END;
