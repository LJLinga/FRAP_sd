CREATE TRIGGER posts_AFTER_UPDATE
AFTER UPDATE ON posts
FOR EACH ROW
  BEGIN
IF(new.statusId != old.statusId) THEN
	IF(new.statusId = 4) THEN 
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT old.authorId, old.id, CONCAT('Your post "',new.title,'" has been published by ', e.LASTNAME,', ', e.FIRSTNAME), new.lastUpdated
		FROM posts p JOIN employee e ON new.publisherId = e.EMP_ID AND p.id = old.id;
    END IF;
    IF(new.statusId = 3 AND old.statusId = 2) THEN 
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT old.authorId, old.id, CONCAT('Your post "',new.title,'" has been reviewed by ', e.LASTNAME,', ', e.FIRSTNAME), new.lastUpdated
		FROM posts p JOIN employee e ON new.reviewedById = e.EMP_ID WHERE p.id=old.id;
        INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT e.EMP_ID, old.id, CONCAT('"',new.title,'" needs publication review'), new.lastUpdated
		FROM employee e JOIN cms_roles c ON c.id = e.CMS_ROLE WHERE c.id = 4;
    END IF;
    IF(new.statusId = 3 AND old.statusId = 4) THEN 
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT old.authorId, old.id, CONCAT('Your post "',new.title,'" has been unpublished by ', e.LASTNAME,', ', e.FIRSTNAME), new.lastUpdated
		FROM posts p JOIN employee e ON new.reviewedById = e.EMP_ID WHERE p.id=old.id;
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT e.EMP_ID, old.id, CONCAT('"',new.title,'" needs publication review'), new.lastUpdated
		FROM employee e JOIN cms_roles c ON c.id = e.CMS_ROLE WHERE c.id = 4;
    END IF;
    IF(new.statusId = 2) THEN 
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT e.EMP_ID, old.id, CONCAT('"',new.title,'" needs review'), new.lastUpdated
		FROM employee e JOIN cms_roles c ON c.id = e.CMS_ROLE WHERE c.id = 3;
    END IF;
    IF(new.statusId = 1 AND old.statusId = 2) THEN 
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT old.authorId, old.id, CONCAT('Your post "',new.title,'" has been rejected by ', e.LASTNAME,', ', e.FIRSTNAME), new.lastUpdated
		FROM posts p JOIN employee e ON new.reviewedById = e.EMP_ID AND p.id = old.id;
    END IF;
    IF(new.statusId = 1 AND old.statusId = 3) THEN 
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT old.authorId, old.id, CONCAT('Your post "',new.title,'" has been rejected by ', e.LASTNAME,', ', e.FIRSTNAME), new.lastUpdated
		FROM posts p JOIN employee e ON new.publisherId = e.EMP_ID AND p.id = old.id;
    END IF;
    IF(new.statusId = 1 AND old.statusId = 4) THEN 
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT old.authorId, old.id, CONCAT('Your post "',new.title,'" has been rejected by ', e.LASTNAME,', ', e.FIRSTNAME), new.lastUpdated
		FROM posts p JOIN employee e ON new.reviewedById = e.EMP_ID AND p.id = old.id;
    END IF;
    IF(new.statusId = 5 AND new.archivedById != old.authorId) THEN 
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT old.authorId, old.id, CONCAT('Your post "',new.title,'" has been archived by ', e.LASTNAME,', ', e.FIRSTNAME), new.lastUpdated
		FROM posts p JOIN employee e ON new.reviewedById = e.EMP_ID AND p.id = old.id;
    END IF;
    IF(old.statusId = 5) THEN 
		INSERT INTO post_activity
		(displayToId, postId, message, timeStamp)
		SELECT old.authorId, old.id, CONCAT('Your post "',new.title,'" has been restored by ', e.LASTNAME,', ', e.FIRSTNAME), new.lastUpdated
		FROM posts p JOIN employee e ON new.reviewedById = e.EMP_ID AND p.id = old.id;
    END IF;
END IF;
END;
