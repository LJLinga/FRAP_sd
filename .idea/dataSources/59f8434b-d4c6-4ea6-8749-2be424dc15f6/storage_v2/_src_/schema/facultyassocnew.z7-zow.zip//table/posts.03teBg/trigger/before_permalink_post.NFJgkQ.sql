CREATE TRIGGER before_permalink_post
BEFORE UPDATE ON posts
FOR EACH ROW
  IF (old.permalink IS NULL) THEN
SET new.permalink = CONCAT(new.permalink,'-', DATE_FORMAT(old.timePublished,'%Y%m%d%H%i%s'));
END IF;
