CREATE TRIGGER sections_BEFORE_UPDATE
BEFORE UPDATE ON sections
FOR EACH ROW
  BEGIN
	
	IF(old.versionNo != new.versionNo OR old.title!=new.title OR old.content!=new.content)THEN
		SET new.audit_action_type = 'UPDATED';
		SET new.audit_user_id = new.authorId;
		SET new.lastUpdated = new.audit_timestamp;
	ELSEIF(old.statusId != new.statusId) THEN
		SET new.audit_action_type = 'STATUSED';
		SET new.audit_user_id = new.statusedById;
		SET new.statusedOn = new.audit_timestamp;
		IF(old.stepId != new.stepId) THEN
			SET new.audit_action_type = 'STATUSED/MOVED';
			SET new.steppedOn = new.audit_timestamp;
		END IF;
	ELSEIF(old.stepId != new.stepId) THEN
		SET new.audit_action_type = 'MOVED';
		SET new.audit_user_id = new.steppedById;
		SET new.steppedOn = new.audit_timestamp;
	ELSEIF(old.lifecycleId != new.lifecycleId) THEN
		SET new.audit_action_type = 'CYCLED';
		SET new.audit_user_id = new.lifecycledById;
		SET new.lifecycledOn = new.audit_timestamp;
	ELSEIF(old.availabilityId != new.availabilityId) THEN
		SET new.audit_action_type = 'LOCKED';
		SET new.audit_user_id = new.availabilityById;
		SET new.availabilityOn = new.audit_timestamp;
	END IF;
	
	IF (new.audit_action_type != 'LOCKED') THEN
		SET new.remark_action_type = new.audit_action_type;
		SET new.remark_user_id = new.audit_user_id;
		SET new.remark_timestamp = new.audit_timestamp;
	END IF;
	
	INSERT INTO section_versions
		(sectionId, 
        firstAuthorId, 
        authorId, 
        timeCreated, 
        lastUpdated,
				availabilityId,
				availabilityOn,
				availabilityById,
				steppedById,
				steppedOn,
				stepId,
        statusedById,
				statusedOn,
        statusId,
				lifecycleId,
				lifecycledById,
				lifecycledOn,
        versionNo, 
        title, 
        remarks,
				audit_action_type,
				audit_user_id,
				audit_timestamp,
				remark_action_type,
				remark_user_id,
				remark_timestamp)
        VALUES 
        (new.id, 
        new.firstAuthorId, 
        new.authorId, 
        new.timeCreated, 
        new.lastUpdated,
				new.availabilityId,
				new.availabilityOn,
				new.availabilityById,
				new.steppedById,
				new.steppedOn,
				new.stepId,
        new.statusedById,
				new.statusedOn,
        new.statusId,
				new.lifecycleId,
				new.lifecycledById,
				new.lifecycledOn,
        new.versionNo, 
        new.title, 
        new.remarks,
				new.audit_action_type,
				new.audit_user_id,
				new.audit_timestamp,
				remark_action_type,
				remark_user_id,
				remark_timestamp);
END;
