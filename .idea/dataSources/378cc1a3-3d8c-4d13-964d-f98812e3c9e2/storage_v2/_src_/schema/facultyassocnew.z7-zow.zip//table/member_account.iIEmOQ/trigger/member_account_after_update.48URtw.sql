create definer = root@`127.0.0.1` trigger member_account_AFTER_UPDATE
    after UPDATE
    on member_account
    for each row
BEGIN
UPDATE facultyassocnew.employee set pass_word = new.password,FIRST_CHANGE_PW = new.FIRST_CHANGE_PW where facultyassocnew.employee.EMP_ID = new.member_ID ;
END;

