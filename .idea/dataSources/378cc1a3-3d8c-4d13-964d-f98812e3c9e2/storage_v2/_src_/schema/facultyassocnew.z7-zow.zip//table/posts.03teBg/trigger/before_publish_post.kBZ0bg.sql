create definer = root@localhost trigger before_publish_post
    before UPDATE
    on posts
    for each row
    IF (new.statusId = 4 AND old.timePublished IS NULL) THEN
	SET new.timePublished = new.lastUpdated;
END IF;

