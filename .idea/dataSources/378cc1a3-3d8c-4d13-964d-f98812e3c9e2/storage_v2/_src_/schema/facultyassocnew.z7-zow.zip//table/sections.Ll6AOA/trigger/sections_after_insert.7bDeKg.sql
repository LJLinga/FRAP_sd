create definer = root@localhost trigger sections_AFTER_INSERT
    after INSERT
    on sections
    for each row
BEGIN
	INSERT INTO section_versions
		(sectionId, statusId, authorId, approvedById, sectionNo, title, content, timeCreated)
        VALUES (new.id, new.statusId, new.authorId, new.approvedById, new.sectionNo, new.title, new.content, new.timeCreated);
END;

