create definer = root@localhost trigger sections_AFTER_INSERT
    after INSERT
    on sections
    for each row
BEGIN
	INSERT INTO section_versions
		(sectionId, 
        firstAuthorId, 
        authorId, 
        timeCreated, 
        lastUpdated,
				availabilityId,
				availabilityOn,
				availabilityById,
				steppedById,
				steppedOn,
				stepId,
        statusedById,
				statusedOn,
        statusId,
				lifecycleStateId,
				lifecycleStatedById,
				lifecycleStatedOn,
        versionNo, 
        title,  
        remarks,
				audit_action_type,
				audit_user_id,
				audit_timestamp)
        VALUES 
        (new.id, 
        new.firstAuthorId, 
        new.authorId, 
        new.timeCreated, 
        new.lastUpdated,
				new.availabilityId,
				new.availabilityOn,
				new.availabilityById,
				new.steppedById,
				new.steppedOn,
				new.stepId,
        new.statusedById,
				new.statusedOn,
        new.statusId,
				new.lifecycleId,
				new.lifecycledById,
				new.lifecycledOn,
        new.versionNo, 
        new.title, 
        new.remarks,
				new.audit_action_type,
				new.audit_user_id,
				new.audit_timestamp);
END;

