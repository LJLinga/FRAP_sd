create definer = root@localhost trigger AUTO_CREATE_CREATOR
    after INSERT
    on steps
    for each row
BEGIN   
	IF(new.stepTypeId = '1') THEN
		INSERT INTO step_author(stepId, `read`, `write`, `route`, `comment`) VALUES (new.id,'2','2','2','2');
	ELSE
		INSERT INTO step_author(stepId, `read`, `write`, `route`, `comment`) VALUES (new.id,'2','1','1','2');
	END IF;
END;

