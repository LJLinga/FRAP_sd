create definer = root@localhost trigger before_trash_post
    before UPDATE
    on posts
    for each row
BEGIN
    IF (new.statusId = 5 AND old.statusId!=new.statusId) THEN
	SET new.previousStatusId = old.statusId ;
END IF;
END;

