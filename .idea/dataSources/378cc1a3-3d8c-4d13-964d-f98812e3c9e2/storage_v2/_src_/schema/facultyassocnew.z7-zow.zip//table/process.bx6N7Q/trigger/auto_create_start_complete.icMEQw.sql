create definer = root@localhost trigger AUTO_CREATE_START_COMPLETE
    after INSERT
    on process
    for each row
BEGIN 
INSERT INTO steps (processId, stepNo, stepName, isFinal, stepTypeId) VALUES (new.id, '1','Start',1,1);
INSERT INTO steps (processId, stepNo, stepName, isFinal, stepTypeId) VALUES (new.id, '2','Complete',1,3);
END;

