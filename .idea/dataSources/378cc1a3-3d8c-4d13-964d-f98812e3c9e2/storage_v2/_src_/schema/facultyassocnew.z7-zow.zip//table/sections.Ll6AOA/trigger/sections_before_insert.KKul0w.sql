create definer = root@localhost trigger sections_BEFORE_INSERT
    before INSERT
    on sections
    for each row
BEGIN
	SET new.audit_user_id = new.firstAuthorId;
	SET new.audit_action_type = "CREATED";
END;

