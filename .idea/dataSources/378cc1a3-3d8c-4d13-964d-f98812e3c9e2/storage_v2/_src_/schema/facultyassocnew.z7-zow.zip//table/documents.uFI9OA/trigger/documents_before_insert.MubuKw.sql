create definer = root@localhost trigger documents_BEFORE_INSERT
    before INSERT
    on documents
    for each row
BEGIN
	SET new.audit_user_id = new.firstAuthorId;
	SET new.audit_action_type = "CREATED";
END;

