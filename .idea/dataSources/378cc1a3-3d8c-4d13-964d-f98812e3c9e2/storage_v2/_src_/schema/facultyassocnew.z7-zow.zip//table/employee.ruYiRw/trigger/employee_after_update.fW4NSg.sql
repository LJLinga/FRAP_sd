create definer = root@`127.0.0.1` trigger employee_AFTER_UPDATE
    after UPDATE
    on employee
    for each row
BEGIN
	UPDATE member set FIRSTNAME = new.FIRSTNAME,LASTNAME = new.LASTNAME where member_id = new.emp_id;
END;

