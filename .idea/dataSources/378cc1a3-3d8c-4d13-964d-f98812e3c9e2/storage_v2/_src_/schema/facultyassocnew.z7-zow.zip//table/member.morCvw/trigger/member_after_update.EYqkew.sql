create definer = root@`127.0.0.1` trigger member_AFTER_UPDATE
    after UPDATE
    on member
    for each row
BEGIN
	IF(old.MEMBERSHIP_STATUS != new.membership_status && new.MEMBERSHIP_STATUS = 2) THEN
	INSERT INTO facultyassocnew.member_account(MEMBER_ID,PASSWORD,FIRST_CHANGE_PW)
    VALUES (new.MEMBER_ID,password('1234'),1);
    INSERT INTO facultyassocnew.employee(EMP_ID,MEMBER_ID,PASS_WORD,FIRSTNAME,LASTNAME,DATE_CREATED,ACC_STATUS,FIRST_CHANGE_PW)
    VALUES (new.MEMBER_ID,new.MEMBER_ID,password('1234'),new.FIRSTNAME,new.LASTNAME,DATE(now()),2,1);
    END IF;
END;

