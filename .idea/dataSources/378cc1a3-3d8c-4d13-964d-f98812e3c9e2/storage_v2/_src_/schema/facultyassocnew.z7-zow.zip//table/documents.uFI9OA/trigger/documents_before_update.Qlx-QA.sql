create definer = root@localhost trigger documents_BEFORE_UPDATE
    before UPDATE
    on documents
    for each row
BEGIN

	DECLARE ACTION VARCHAR(100);
	DECLARE DOER INT(8);
	
	IF(old.title != new.title OR old.filePath!=new.filePath OR old.versionNo != new.versionNo)THEN
		SET ACTION = 'UPDATED';
		SET DOER = new.authorId;
		SET new.lastUpdated = CURRENT_TIMESTAMP;
	ELSEIF(old.statusId != new.statusId) THEN
		SET ACTION = 'STATUSED';
		SET DOER = new.statusedById;
		SET new.statusedOn = CURRENT_TIMESTAMP;
		IF(old.stepId != new.stepId) THEN
			SET new.steppedOn = CURRENT_TIMESTAMP;
		END IF;
	ELSEIF(old.stepId != new.stepId) THEN
		SET ACTION = 'MOVED';
		SET DOER = new.steppedById;
		SET new.steppedOn = CURRENT_TIMESTAMP;
	ELSEIF(old.lifecycleStateId != new.lifecycleStateId) THEN
		SET ACTION = 'CYCLED';
		SET DOER = new.lifecycleStatedById;
	ELSEIF(old.availabilityId != new.availabilityId) THEN
		SET ACTION = 'LOCKED';
		SET DOER = new.availabilityById;
	END IF;
	
	INSERT INTO doc_versions
		(documentId, 
        firstAuthorId, 
        authorId, 
        timeCreated, 
        lastUpdated,
				steppedById,
				steppedOn,
				stepId,
        statusedById,
				statusedOn,
        statusId,
				lifecycleStateId,
				lifecycleStatedById,
				lifecycleStatedOn,
				typeId,
        versionNo, 
        title, 
        filePath, 
        remarks,
				audit_action_type,
				audit_user_id)
        VALUES 
        (new.documentId, 
        new.firstAuthorId, 
        new.authorId, 
        new.timeCreated, 
        new.lastUpdated,
				new.steppedById,
				new.steppedOn,
				new.stepId,
        new.statusedById,
				new.statusedOn,
        new.statusId,
				new.lifecycleStateId,
				new.lifecycleStatedById,
				new.lifecycleStatedOn,
				new.typeId,
        new.versionNo, 
        new.title, 
        new.filePath, 
        new.remarks,
				ACTION,
				DOER);
END;

