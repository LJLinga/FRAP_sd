create definer = root@localhost trigger documents_BEFORE_UPDATE
    before UPDATE
    on documents
    for each row
BEGIN
	
	IF(old.title != new.title OR old.filePath!=new.filePath OR old.versionNo != new.versionNo)THEN
		SET new.audit_action_type = 'UPDATED';
		SET new.audit_user_id = new.authorId;
		SET new.lastUpdated = new.audit_timestamp;
	ELSEIF(old.statusId != new.statusId) THEN
		SET new.audit_action_type = 'STATUSED';
		SET new.audit_user_id = new.statusedById;
		SET new.statusedOn = CURRENT_TIMESTAMP;
		IF(old.stepId != new.stepId) THEN
			SET new.audit_action_type = 'STATUSED/MOVED';
			SET new.steppedOn = CURRENT_TIMESTAMP;
		END IF;
	ELSEIF(old.stepId != new.stepId) THEN
		SET new.audit_action_type = 'MOVED';
		SET new.audit_user_id = new.steppedById;
		SET new.steppedOn = CURRENT_TIMESTAMP;
	ELSEIF(old.lifecycleStateId != new.lifecycleStateId) THEN
		SET new.audit_action_type = 'CYCLED';
		SET new.audit_user_id = new.lifecycleStatedById;
		SET new.lifecycleStatedOn = CURRENT_TIMESTAMP;
	ELSEIF(old.availabilityId != new.availabilityId) THEN
		SET new.audit_action_type = 'LOCKED';
		SET new.audit_user_id = new.availabilityById;
		SET new.availabilityOn = CURRENT_TIMESTAMP;
	END IF;
	
	INSERT INTO doc_versions
		(documentId, 
        firstAuthorId, 
        authorId, 
        timeCreated, 
        lastUpdated,
				availabilityId,
				availabilityOn,
				availabilityById,
				steppedById,
				steppedOn,
				stepId,
        statusedById,
				statusedOn,
        statusId,
				lifecycleStateId,
				lifecycleStatedById,
				lifecycleStatedOn,
				typeId,
        versionNo, 
        title, 
        filePath, 
        remarks,
				audit_action_type,
				audit_user_id)
        VALUES 
        (new.documentId, 
        new.firstAuthorId, 
        new.authorId, 
        new.timeCreated, 
        new.lastUpdated,
				new.availabilityId,
				new.availabilityOn,
				new.availabilityById,
				new.steppedById,
				new.steppedOn,
				new.stepId,
        new.statusedById,
				new.statusedOn,
        new.statusId,
				new.lifecycleStateId,
				new.lifecycleStatedById,
				new.lifecycleStatedOn,
				new.typeId,
        new.versionNo, 
        new.title, 
        new.filePath, 
        new.remarks,
				new.audit_action_type,
				new.audit_user_id);
END;

