create definer = root@localhost trigger documents_BEFORE_UPDATE
    before UPDATE
    on documents
    for each row
BEGIN
	IF(old.title != new.title OR old.filePath!=new.filePath OR old.versionNo != new.versionNo)THEN
		SET new.lastUpdated = CURRENT_TIMESTAMP;
	END IF;
END;

