create definer = root@localhost trigger documents_AFTER_UPDATE
    after UPDATE
    on documents
    for each row
BEGIN

	DECLARE ACTION VARCHAR(100);
	IF(old.title != new.title OR old.filePath!=new.filePath OR old.versionNo != new.versionNo)THEN
		SET ACTION = "UPDATE CONTENT";
	ELSEIF(old.statusId != new.statusId AND new.statusId != 1) THEN
		SET ACTION = 'UPDATE STATUS';
	ELSEIF(old.stepId != new.stepId) THEN
		SET ACTION = 'UPDATE STAGE';
	ELSEIF(old.lifecycleStateId != new.lifecycleStateId) THEN
		SET ACTION = 'UPDATE STATE';
	ELSE
		SET ACTION = 'UPDATE LOCK';
	END IF;
	
	IF(ACTION != 'UPDATE LOCK') THEN
	INSERT INTO doc_versions
		(documentId, 
        firstAuthorId, 
        authorId, 
        timeCreated, 
        lastUpdated,
				steppedById,
				steppedOn,
				stepId,
        statusedById,
				statusedOn,
        statusId,
				lifecycleStateId,
				lifecycleStatedById,
				lifecycleStatedOn,
				typeId,
        versionNo, 
        title, 
        filePath, 
        remarks,
				audit_action_type)
        VALUES 
        (new.documentId, 
        new.firstAuthorId, 
        new.authorId, 
        new.timeCreated, 
        new.lastUpdated,
				new.steppedById,
				new.steppedOn,
				new.stepId,
        new.statusedById,
				new.statusedOn,
        new.statusId,
				new.lifecycleStateId,
				new.lifecycleStatedById,
				new.lifecycleStatedOn,
				new.typeId,
        new.versionNo, 
        new.title, 
        new.filePath, 
        new.remarks,
				ACTION);
			END IF;

END;

