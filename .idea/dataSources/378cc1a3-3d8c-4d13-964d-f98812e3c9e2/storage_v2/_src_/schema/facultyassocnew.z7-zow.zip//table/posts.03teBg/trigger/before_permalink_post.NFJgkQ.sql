create definer = root@localhost trigger before_permalink_post
    before UPDATE
    on posts
    for each row
    IF (old.permalink IS NULL) THEN
SET new.permalink = CONCAT(new.permalink,'-', DATE_FORMAT(old.timePublished,'%Y%m%d%H%i%s'));
END IF;

