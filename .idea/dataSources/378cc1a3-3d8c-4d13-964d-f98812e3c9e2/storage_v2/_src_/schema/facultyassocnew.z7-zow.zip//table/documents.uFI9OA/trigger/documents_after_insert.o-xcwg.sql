create definer = root@localhost trigger documents_AFTER_INSERT
    after INSERT
    on documents
    for each row
BEGIN
	INSERT INTO doc_versions
		(documentId, 
        firstAuthorId, 
        authorId, 
        timeCreated, 
        lastUpdated,
				steppedById,
				steppedOn,
				stepId,
        statusedById,
				statusedOn,
        statusId,
				lifecycleStateId,
				lifecycleStatedById,
				lifecycleStatedOn,
				typeId,
        versionNo, 
        title, 
        filePath, 
        remarks,
				audit_action_type)
        VALUES 
        (new.documentId, 
        new.firstAuthorId, 
        new.authorId, 
        new.timeCreated, 
        new.lastUpdated,
				new.steppedById,
				new.steppedOn,
				new.stepId,
        new.statusedById,
				new.statusedOn,
        new.statusId,
				new.lifecycleStateId,
				new.lifecycleStatedById,
				new.lifecycleStatedOn,
				new.typeId,
        new.versionNo, 
        new.title, 
        new.filePath, 
        new.remarks,
				"CREATED");
END;

