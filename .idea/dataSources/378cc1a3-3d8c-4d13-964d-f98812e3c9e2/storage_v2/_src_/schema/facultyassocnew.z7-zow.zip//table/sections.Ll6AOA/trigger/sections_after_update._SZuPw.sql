create definer = root@localhost trigger sections_AFTER_UPDATE
    after UPDATE
    on sections
    for each row
BEGIN
	IF(old.title != new.title OR old.content!=new.content OR old.sectionNo != new.sectionNo) THEN
		INSERT INTO section_versions
		(sectionId, authorId, statusId, approvedById, sectionNo, title, content, timeCreated)
        VALUES (new.id, new.authorId, new.statusId, new.approvedById, new.sectionNo, new.title, new.content, new.lastUpdated);
	END IF;
    
END;

