create definer = root@localhost trigger sections_BEFORE_UPDATE
    before UPDATE
    on sections
    for each row
BEGIN
	
	IF(old.versionNo != new.versionNo)THEN
		SET new.audit_action_type = 'UPDATED';
		SET new.audit_user_id = new.authorId;
		SET new.lastUpdated = new.audit_timestamp;
	ELSEIF(old.statusId != new.statusId) THEN
		SET new.audit_action_type = 'STATUSED';
		SET new.audit_user_id = new.statusedById;
		SET new.statusedOn = CURRENT_TIMESTAMP;
		IF(old.stepId != new.stepId) THEN
			SET new.audit_action_type = 'STATUSED/MOVED';
			SET new.steppedOn = CURRENT_TIMESTAMP;
		END IF;
	ELSEIF(old.stepId != new.stepId) THEN
		SET new.audit_action_type = 'MOVED';
		SET new.audit_user_id = new.steppedById;
		SET new.steppedOn = CURRENT_TIMESTAMP;
	ELSEIF(old.lifecycleId != new.lifecycleId) THEN
		SET new.audit_action_type = 'CYCLED';
		SET new.audit_user_id = new.lifecycledById;
		SET new.lifecycledOn = CURRENT_TIMESTAMP;
	ELSEIF(old.availabilityId != new.availabilityId) THEN
		SET new.audit_action_type = 'LOCKED';
		SET new.audit_user_id = new.availabilityById;
		SET new.availabilityOn = CURRENT_TIMESTAMP;
	END IF;
	
	INSERT INTO section_versions
		(sectionId, 
        firstAuthorId, 
        authorId, 
        timeCreated, 
        lastUpdated,
				availabilityId,
				availabilityOn,
				availabilityById,
				steppedById,
				steppedOn,
				stepId,
        statusedById,
				statusedOn,
        statusId,
				lifecycleStateId,
				lifecycleStatedById,
				lifecycleStatedOn,
        versionNo, 
        title, 
        remarks,
				audit_action_type,
				audit_user_id,
				audit_timestamp)
        VALUES 
        (new.id, 
        new.firstAuthorId, 
        new.authorId, 
        new.timeCreated, 
        new.lastUpdated,
				new.availabilityId,
				new.availabilityOn,
				new.availabilityById,
				new.steppedById,
				new.steppedOn,
				new.stepId,
        new.statusedById,
				new.statusedOn,
        new.statusId,
				new.lifecycleId,
				new.lifecycledById,
				new.lifecycledOn,
        new.versionNo, 
        new.title, 
        new.remarks,
				new.audit_action_type,
				new.audit_user_id,
				new.audit_timestamp);
END;

