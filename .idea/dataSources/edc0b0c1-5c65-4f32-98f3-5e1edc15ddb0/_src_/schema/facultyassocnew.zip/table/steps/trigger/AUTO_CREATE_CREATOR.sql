CREATE TRIGGER AUTO_CREATE_CREATOR
AFTER INSERT ON steps
FOR EACH ROW
  BEGIN   
	IF(new.stepTypeId = '1') THEN
		INSERT INTO step_author(stepId, `read`, `write`, `route`, `comment`) VALUES (new.id,'2','2','2','2');
	ELSE
		INSERT INTO step_author(stepId, `read`, `write`, `route`, `comment`) VALUES (new.id,'2','1','1','2');
	END IF;
END;
