CREATE TRIGGER employee_AFTER_UPDATE
AFTER UPDATE ON employee
FOR EACH ROW
  BEGIN
	UPDATE member set FIRSTNAME = new.FIRSTNAME,LASTNAME = new.LASTNAME where member_id = new.emp_id;
    
    
END;
