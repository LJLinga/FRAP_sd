CREATE TRIGGER before_trash_post
BEFORE UPDATE ON posts
FOR EACH ROW
  IF (new.statusId = 5 AND old.statusId!=new.statusId) THEN
	SET new.previousStatusId = old.statusId ;
	END IF;
