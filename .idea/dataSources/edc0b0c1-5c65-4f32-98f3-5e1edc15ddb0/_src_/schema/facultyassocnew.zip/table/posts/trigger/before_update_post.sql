CREATE TRIGGER before_update_post
BEFORE UPDATE ON posts
FOR EACH ROW
  IF(old.statusId = new.statusId) THEN
		SET new.remark_action_type = 'UPDATED';
		SET new.remark_timestamp = new.lastUpdated;
	ELSEIF (old.statusId = 5 AND new.statusId != 5) THEN
		SET new.remark_action_type = 'RESTORED';
        SET new.remark_user_id = new.restoredById;
				SET new.remark_timestamp = new.lastUpdated;
	ELSEIF(new.statusId = 4) THEN
		SET new.remark_action_type = 'PUBLISHED';
        SET new.remark_user_id = new.publisherId;
				SET new.remark_timestamp = new.lastUpdated;
	ELSEIF (new.statusId = 3) THEN
		SET new.remark_action_type = 'REVIEWED';
        SET new.remark_user_id = new.reviewedById;
				SET new.remark_timestamp = new.lastUpdated;
	ELSEIF (new.statusId = 2) THEN
		SET new.remark_action_type = 'SUBMITTED';
        SET new.remark_user_id = new.authorId;
				SET new.remark_timestamp = new.lastUpdated;
	ELSEIF (new.statusId = 5) THEN
		SET new.remark_action_type = 'ARCHIVED';
        SET new.remark_user_id = new.archivedById;
				SET new.remark_timestamp = new.lastUpdated;
	END IF;
