CREATE TRIGGER documents_BEFORE_INSERT
BEFORE INSERT ON documents
FOR EACH ROW
  BEGIN
	SET new.audit_user_id = new.firstAuthorId;
	SET new.audit_action_type = "CREATED";
END;
