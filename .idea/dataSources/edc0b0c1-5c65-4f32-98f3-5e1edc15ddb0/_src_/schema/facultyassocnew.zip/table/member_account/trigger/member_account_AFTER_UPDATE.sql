CREATE TRIGGER member_account_AFTER_UPDATE
AFTER UPDATE ON member_account
FOR EACH ROW
  BEGIN
UPDATE facultyassocnew.employee set pass_word = new.password,FIRST_CHANGE_PW = new.FIRST_CHANGE_PW where facultyassocnew.employee.EMP_ID = new.member_ID ;
END;
